A Pen created at CodePen.io. You can find this one at http://codepen.io/Taron/pen/jyeIi.

 Photo slider working on desktop and mobile browsers.
