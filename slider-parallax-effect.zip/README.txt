A Pen created at CodePen.io. You can find this one at http://codepen.io/mmadeira/pen/jrBxpE.

 A slider inspired by a Dribbble created by Jardson Almeida  (https://dribbble.com/shots/2518516-Nike-Promotion-Ads-Parallax-Effect).